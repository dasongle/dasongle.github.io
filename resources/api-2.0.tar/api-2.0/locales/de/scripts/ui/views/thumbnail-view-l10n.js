/*==================================================
 *  Exhibit.ThumbnailView German localization
 *==================================================
 */

if (!("l10n" in Exhibit.ThumbnailView)) {
    Exhibit.ThumbnailView.l10n = {};
}

Exhibit.ThumbnailView.l10n.viewLabel = "Vorschaubilder";
Exhibit.ThumbnailView.l10n.viewTooltip = "Zeige Elemente als Vorschaubilder";
