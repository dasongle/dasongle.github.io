/*==================================================
 *  Exhibit.ThumbnailView Swedish localization
 *==================================================
 */

if (!("l10n" in Exhibit.ThumbnailView)) {
    Exhibit.ThumbnailView.l10n = {};
}

Exhibit.ThumbnailView.l10n.viewLabel = "Tumnaglar";
Exhibit.ThumbnailView.l10n.viewTooltip = "Visa som tumnaglar";
