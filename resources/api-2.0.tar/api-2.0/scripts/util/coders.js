/*==================================================
 *  Exhibit.Coders
 *==================================================
 */

Exhibit.Coders = new Object();

Exhibit.Coders.mixedCaseColor=  "#fff";
Exhibit.Coders.othersCaseColor = "#aaa";
Exhibit.Coders.missingCaseColor = "#888";
